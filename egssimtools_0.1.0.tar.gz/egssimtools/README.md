#egsimtools: R package for the analysis of the EGS simulation

Check out the vignette of the package in the `doc` folder. You can visualize the `pdf` version online from GitHub. Alternatively, download the repository and open the `html` version in your browser.