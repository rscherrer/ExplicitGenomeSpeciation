#' Read time record
#'
#' @param filename Path to the folder
#'
#' @export

read_time <- function(folder) {

  read_data(folder, "time")

}
